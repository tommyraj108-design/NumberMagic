package com.example.numbermagic

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View

class MagicNumberView(context: Context) : View(context) {
    private var number = 1
    private var revealed = false

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(12, 12, 15)
        style = Paint.Style.FILL
    }
    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("casual", Typeface.NORMAL)
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(100, 100, 110)
        textAlign = Paint.Align.CENTER
        textSize = 38f
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    fun setNumber(value: Int, show: Boolean) {
        number = value
        revealed = show
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)

        if (revealed) {
            numberPaint.textSize = height * 0.48f
            val baseline = height / 2f - (numberPaint.ascent() + numberPaint.descent()) / 2f
            canvas.drawText(number.toString(), width / 2f, baseline, numberPaint)
        } else {
            // Keep the screen visually clean so the secret number is not visible.
            canvas.drawText("", width / 2f, height / 2f, hintPaint)
        }
    }
}
