# Number Magic Android

A simple fullscreen Android app for a number-magic routine:
- Volume Up cycles the secret number 1 → 2 → ... → 9 → 1.
- Volume Down reveals the current number.
- Tap the screen to hide the number again and continue.

The number is rendered in a casual handwritten-style system typeface. Actual appearance can vary by Android device.

## Build an APK with GitHub Actions
1. Create a new repository on GitHub.
2. Upload all files and folders from this project ZIP (upload the contents, not the ZIP itself).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. The workflow **Build Number Magic APK** runs on push. It also can be started from **Actions → Build Number Magic APK → Run workflow**.
5. Open the completed workflow run, then download the **NumberMagic-debug-apk** artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

## Important behavior
Android lets an app intercept volume keys while its Activity is in the foreground. Keep Number Magic open on screen while performing the trick. The app does not listen to volume buttons while it is in the background or the phone is locked.
